#define SQLITE_PTR_SZ 4
